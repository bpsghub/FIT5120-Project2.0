// Service exports for easy importing
import realFacilityService from './facilityService.js'

// Use real facility service that loads from JSON files
const facilityService = realFacilityService

export { facilityService }
